<?php
 if (!isset($_SESSION['login'])) {
  header("Location: http://".$_SERVER["SERVER_NAME"] .":8081/akma/login.php");
}
if (isset($_GET['id'])) {

	$id=$_GET['id'];
$conn= new mysqli("localhost","root","","akma");
$sql = "DELETE FROM users WHERE id='$id'";
$result = $conn->query($sql);
header("Location: http://".$_SERVER["SERVER_NAME"] . ":8081/akma/admin.php");

}
?>
