<?php session_start();
require_once("section/header.php"); 

if (isset($_POST['register'])) {
$name=$_POST["name"];
$login=$_POST["login"];
$password=$_POST["password"];
$email=$_POST["email"];
$phone=$_POST["phone"];

$conn=new mysqli("localhost","root","","akma");

 include "function.php";

   if(LoginChecker($login)){
        $sql="INSERT INTO users2 (name,login,pass,email,phone) VALUES ('$name','$login','$password','$email','$phone')";
        $result=$conn->query($sql);
           
            echo "<script>alert('Register succesfully')</script>" ;   

        }
        else{
            echo "<script>alert('Enter another login!!')</script>" ;   
                        }
}

?>

    
  <div class="form_settings">
    <form  method="post">
     <input type="text" name= "name"     placeholder="Введите name"required>
      <br>
      <br>
      <input type="text" name="login" placeholder="Введите login" required>
      <br>
      <br>
       <input type="password" name="password" placeholder="Введите password" required>
      <br>
      <br>
      <input type="text" name="email" placeholder="Введите email"required>
      <br>
      <br>
       <input type="tel" name="phone" placeholder="Введите phone"required>
      <br>
      <br>
      <input type="submit" name="register" value="Register">
       <a href="login.php">Return</a></p>
    </form>
  </div>


</body>
</html>