<?php session_start();


 require_once("section/header.php") ?>
 
    <div id="site_content">
      <div id="sidebar_container">
        <div class="sidebar">
          <h3>News</h3>
         
          <h5>13 may 2016</h5>
          <p>13 may Master class by Goar Avestisyan<br /><a href="http://makeupstudio.kz/"> read More</a></p>
        </div>
        <div class="sidebar">
          <h3>Useful Links</h3>
          <ul>
            <li><a href="#">First Link</a></li>
            <li><a href="#">Another Link</a></li>
            <li><a href="#">And Another</a></li>
            <li><a href="#">One More</a></li>
            <li><a href="#">Last One</a></li>
          </ul>
        </div>
      </div>
	    <div class="work col-md-2 col-sm-6">

                                <div >
                                    <img src="C:\xampp\htdocs\akma\images\class1.jpg" width="600" height="300" >
								
								
                                    <img src="C:\xampp\htdocs\akma\images\class2.jpg" width="300" >
									<img src="C:\xampp\htdocs\akma\images\class3.jpg" width="226">
									<img src="C:\xampp\htdocs\akma\images\class4.jpg" >
									</div>
									
								

                            </div>
		 </div>
    <footer>
      <p>Copyright &copy; : desigened by Akmaral Bolysbay | <a href="#"></a></p>
    </footer>
  </div>
  <p>&nbsp;</p>
  <!-- javascript at the bottom for fast page loading -->
  <script type="text/javascript" src="js/jquery.js"></script>
  <script type="text/javascript" src="js/jquery.easing-sooper.js"></script>
  <script type="text/javascript" src="js/jquery.sooperfish.js"></script>
  <script type="text/javascript">
    $(document).ready(function() {
      $('ul.sf-menu').sooperfish();
    });
  </script>
</body>
</html>
