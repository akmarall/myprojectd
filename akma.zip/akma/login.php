<?php session_start();
require_once("section/header.php"); 

if(isset($_POST["login"])){
$login=$_POST["login"];
$password=$_POST["password"];
$conn= new mysqli("localhost","root","","akma");
$sql="SELECT * FROM users2 WHERE login='$login' AND pass='$password'";

  $result=$conn->query($sql);
   if ($result->num_rows>0) {
       while ($row=$result->fetch_assoc()) {
        if ($row['id']=="1") {
        $_SESSION['login'] = $row['login'];
         $_SESSION['password'] = $row['pass'];
         header("Location: /akma/admin.php");  
        }
        else
        {
          if ($login==null || $login="" and $password==null || $password=="") {

            session_destroy();
            header("Location: /akma/login.php"); 
          } 
          else{
         $_SESSION['login'] = $row['login'];
         $_SESSION['password'] = $row['pass'];
         header("Location: /akma/index.php"); 
       }
        }
}
}
}
 ?>

    
  <div class="form_settings">
    <form  method="post">
     <input class="contact" type="text" name= "login"     placeholder="Введите логин">
      <br>
      <br>
     <br>
     <input class="contact" type="password" name="password" placeholder="Пароль">
      <br>
      <br>
      <br>
     <input type="submit" Value="Login">
      
       <a href="register.php">Register</a></p>
    </form>
  </div>


</body>
</html>