<?php session_start(); 

if (!isset($_SESSION['login'])) {
  header("Location: http://".$_SERVER["SERVER_NAME"] .":8081/akma/login.php");
}
?>

<!DOCTYPE HTML>
<html>

<head>
  <title>Akmaral_make up</title>
  <meta name="description" content="website description" />
  <meta name="keywords" content="website keywords, website keywords" />
  <meta http-equiv="content-type" content="text/html; charset=UTF-8" />
  <link rel="stylesheet" type="text/css" href="css/style.css" />
  <link rel="shortcut icom" href="C:\xampp\htdocs\akma\favicon.ico">  
<script type="text/javascript" src="js/modernizr-1.5.min.js"></script>
</head>

<body>
  <div id="main">
    <header>
      <div id="logo">
        <div id="logo_text">
          <!-- class="logo_colour", allows you to change the colour of the text -->
          <h1><a href="index.php">Akmaral_beauty</a></h1>
          <h2>“Beauty is internal.</h2>
        </div>
      </div>
      <nav>
        <div id="menu_container">
          <ul class="sf-menu" id="nav">
            <li><a href="admin.php" class="active">Admin page</a></li>
            <li><a href="update.php">Update</a></li>

            <li><a href="logout.php">log out</a></li>
            
          </ul>
        </div>
      </nav>
    </header>

 
 <?php
 $servername = "localhost";
$username = "root";
$password = "";
$dbname = "akma";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
$sql = "SELECT * FROM users";
$result = $conn->query($sql);
if ($result->num_rows > 0) {

    while($row = $result->fetch_assoc()) {
    	
        echo "<div class=\"divl\">
      <div class=\"panel panel-primary\">
        <div class=\"panel-heading\">".$row['id'].'    '.'<a href="delete.php?id=' . $row['id'] . '">Delete</a>'.''."</div>
        <div class=\"panel-footer\">".'Name-'.$row['name']."<br>".'Email-'.$row['email']."<br>".'Phone-'.$row['phone']."<br>".'Data-'.$row['data']."<br>".'Message-'.$row['message']."<br></div>
      </div>
    </div>";
    }
} 



?>
