<?php session_start();
if (!isset($_SESSION['login'])) {
  header("Location: http://".$_SERVER["SERVER_NAME"] .":8081/akma/login.php");
}


 require_once("section/header.php") ;


if(isset($_POST["name"])) {
  $name=$_POST["name"];
  $email= $_POST["email"];
  $phone=$_POST["phone"];
  $data=$_POST["data"]."  ".$_POST["time"];
  $message=$_POST["message"];
  

  $conn=new mysqli("Localhost","root","","akma");
  $sql="INSERT INTO users (name,email,phone,data,message) VALUES('$name','$email','$phone','$data','$message')";   
  $conn->query($sql);
    } 
?>

    <div id="site_content">
      <div id="sidebar_container">
        <div class="sidebar">
          <h3>Latest News</h3>
          <h4>New Website Launched</h4>
          <h5>January 1st, 2012</h5>
          <p>2012 sees the redesign of our website. Take a look around and let us know what you think.<br /><a href="#">Read more</a></p>
        </div>
        <div class="sidebar">
          <h3>Useful Links</h3>
          <ul>
            <li><a href="#">First Link</a></li>
            <li><a href="#">Another Link</a></li>
            <li><a href="#">And Another</a></li>
            <li><a href="#">One More</a></li>
            <li><a href="#">Last One</a></li>
          </ul>
        </div>
      </div>
      <div class="content">
        <h1>Contact Us</h1>
                <form id="contact" name="myForm"  onsubmit="return validateForm()" method="post">
          <div class="form_settings">
              <form id="contact"  onsubmit="return validateForm()" method="post">
            <p><span>Name</span><input class="contact" type="text" name="name" /></p>
            <p><span>Email Address</span><input class="contact" type="text" name="email" /></p>
            <p><span>Phone</span><input class="contact" type="text" name="phone"  /></p>
            <p><span>Data</span><input class="contact" type="text" name="data" /></p>
             <select  name="time">
     <?php
     for ($i=10; $i <=19 ; $i++) {

        echo "<option >$i:00</option>";     
       }
       ?>
     </select>
 <br>
            <p><span>Message</span><textarea class="contact textarea" rows="5" cols="50" name="message"></textarea></p>
            </p>
            <p style="padding-top: 15px"><span>&nbsp;</span><input class="submit" type="submit" name="contact_submitted" value="send" /></p>
                </form>
          </div>
        </form>
      </div>
    </div>
     <footer>
      <p>Copyright &copy; : desigened by Akmaral Bolysbay | <a href="#"></a></p>
    </footer>
  </div>
  <p>&nbsp;</p>
 
</body>
</html>
