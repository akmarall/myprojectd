<?php session_start();


 require_once("section/header.php") ?>
 
    <div id="site_content">
      <div id="sidebar_container">
        <div class="sidebar">
          <h3>News</h3>
         
          <h5>13 may 2016</h5>
          <p>13 may Master class by Goar Avestisyan<br /><a href="http://makeupstudio.kz/"> read More</a></p>
        </div>
        <div class="sidebar">
          <h3>Useful Links</h3>
          <ul>
            <li><a href="#">First Link</a></li>
            <li><a href="#">Another Link</a></li>
            <li><a href="#">And Another</a></li>
            <li><a href="#">One More</a></li>
            <li><a href="#">Last One</a></li>
          </ul>
        </div>
      </div>
	    <div > 
		<img src=" C:\xampp\htdocs\akma\images\book.jpg" height="381" width="270">
		</div>
		<div id="book"><h1>Face Paint - The Story of Makeup</h1>
		<p> FacePaint is my first book, all about the history of makeup - something I've always wanted to write.
It's a hardback book (8 x 10 inches), with 60,000 words - full of fascinating, surprising and at times unbelievable stories of how and why the items in your makeup bag got to be there. I also spent a long time sourcing the right images - beautiful paintings, illustrations and iconic photography - to tell the story. You can watch my video below for a sneak peek inside the pages.
If you’re posting about FacePaint on social media, please tag #FacePaintBook so that I can see, like and comment on your posts.
For films, press coverage and blog posts, click here for my Face Paint pinterest board. X</p>
		</div>

		 </div>
    <footer>
      <p>Copyright &copy; : desigened by Akmaral Bolysbay | <a href="#"></a></p>
    </footer>
  </div>
  <p>&nbsp;</p>
  <!-- javascript at the bottom for fast page loading -->
  <script type="text/javascript" src="js/jquery.js"></script>
  <script type="text/javascript" src="js/jquery.easing-sooper.js"></script>
  <script type="text/javascript" src="js/jquery.sooperfish.js"></script>
  <script type="text/javascript">
    $(document).ready(function() {
      $('ul.sf-menu').sooperfish();
    });
  </script>
</body>
</html>
