<?php session_start(); ?>

<!DOCTYPE HTML>
<html>

<head>
  <title>Akmaral_make up</title>
  <meta name="description" content="website description" />
  <meta name="keywords" content="website keywords, website keywords" />
  <meta http-equiv="content-type" content="text/html; charset=UTF-8" />
  <link rel="stylesheet" type="text/css" href="css/style.css" />
  <link rel="shortcut icom" href="C:\Users\Lyazza\Desktop\Akmaral project\favicon.ico">  
<script type="text/javascript" src="js/modernizr-1.5.min.js"></script>
</head>

<body>
  <div id="main">
    <header>
      <div id="logo">
        <div id="logo_text">
          <!-- class="logo_colour", allows you to change the colour of the text -->
          <h1><a href="index.html">Akmaral_beauty</a></h1>
          <h2>“Beauty is internal.</h2>
        </div>
      </div>
      <nav>
        <div id="menu_container">
          <ul class="sf-menu" id="nav">
            <li><a href="admin.php" class="active">Admin page</a></li>
            <li><a href="update.php">Update</a></li>

            <li><a href="logout.php">log out</a></li>
            
          </ul>
        </div>
      </nav>
    </header>

	<?php

 if (isset($_POST['url1'])) {
 	 $churl1=$_POST['url1'];
     $chdes1=$_POST['des1'];
	$conn= new mysqli("Localhost","root","","akma");
    $sql1 = "UPDATE photo SET url ='$churl1' WHERE id='1' " ;
    $sql2 = "UPDATE photo SET des ='$chdes1' WHERE id='1' " ;
	$result=$conn->query($sql1);
	$result2=$conn->query($sql2);

	
}

 else if (isset($_POST['url2'])) {
     $churl2=$_POST['url2'];
     $chdes2=$_POST['des2'];
	$conn= new mysqli("Localhost","root","","akma");
	$sql3 = "UPDATE photo SET url ='$churl2' WHERE id='2' " ;
    $sql4 = "UPDATE photo SET des ='$chdes2' WHERE id='2' " ;
	$result=$conn->query($sql3);
	$result2=$conn->query($sql4);

}
 else if (isset($_POST['url3'])) {
     $churl3=$_POST['url3'];
     $chdes3=$_POST['des3'];

	$conn= new mysqli("Localhost","root","","akma");
	$sql5 = "UPDATE photo SET url ='$churl3' WHERE id='3' " ;
    $sql6 = "UPDATE photo SET des ='$chdes3' WHERE id='3' " ;
	

	$result=$conn->query($sql5);
	$result2=$conn->query($sql5);

}
 else if (isset($_POST['url4'])) {

     $churl4=$_POST['url4'];
     $chdes4=$_POST['des4'];

	$conn= new mysqli("Localhost","root","","akma");
	$sql7 = "UPDATE photo SET url ='$churl4' WHERE id='4' " ;
    $sql8 = "UPDATE photo SET des ='$chdes4' WHERE id='4' " ;

	$result=$conn->query($sql7);
	$result2=$conn->query($sql8);

}


 ?>
<div class="update">
  <form method="post"  >
<h3>Change url and description</h3>
<HR>
<br>
 1 video <input class="bank"  name="url1" >
  description <input class="bank"  name="des1" >
 <input type="submit" value="Change photo">
</form>
<br>
  <form method="post"  >
 2 video <input class="bank"  name="url2" >
  description <input class="bank"  name="des2" >
  <input type="submit" value="Change photo">
</form>
<br>
 <form method="post" >
 3 video <input class="bank"  name="url3" >
  description <input class="bank"  name="des3" >
  <input type="submit" value="Change photo">
</form>
 <br>
  <form method="post"  >
 4 video <input class="bank"  name="url4" >
  description <input class="bank"  name="des4" >
 <input type="submit" value="Change photo">
</form>
</div>



 </body>
 </html>