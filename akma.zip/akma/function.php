<?php
	
	function LoginChecker($login){
		  $conn=new mysqli("Localhost","root","","akma");
		$sql = "SELECT * FROM users2";
		$result = $conn->query($sql);
		$j=0;
		if($result->num_rows > 0){			
			while($row = $result->fetch_assoc()){
				if ($login==$row['login']) {
	            	$j++;
	            }
	        }}
	    if($j>0){
	        return false;
	    }
	    else {
	    	return true;
	    }
	}			
	
?>