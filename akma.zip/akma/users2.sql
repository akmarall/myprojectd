-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Хост: 127.0.0.1
-- Время создания: Май 10 2016 г., 12:29
-- Версия сервера: 10.1.10-MariaDB
-- Версия PHP: 7.0.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `salon`
--

-- --------------------------------------------------------

--
-- Структура таблицы `users2`
--

CREATE TABLE `users2` (
  `id` int(255) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `login` varchar(255) NOT NULL,
  `pass` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `users2`
--

INSERT INTO `users2` (`id`, `name`, `login`, `pass`, `email`, `phone`) VALUES
(1, 'admin', 'admin', 'admin', 'a.maks97@mail.ru', '87023837080'),
(2, 'Maksat', 'max_9700', 'qwerty123', 'a.maks97@mail.ru', '87027837080'),
(3, 'Maksat', '', '', '', ''),
(4, 'Maksat', '', '', '', ''),
(5, 'Maksat', '', '', '', ''),
(6, '', '', '', 'a.maks97@mail.ru', ''),
(7, '', '', '', 'a.maks97@mail.ru', ''),
(8, '', '', '', 'a.maks97@mail.ru', ''),
(9, '', '', '', 'a.maks97@mail.ru', ''),
(10, '', '', '', 'a.maks97@mail.ru', ''),
(11, '', '', '', 'a.maks97@mail.ru', ''),
(12, '', '', '', '', ''),
(13, 'addasd', 'adads', 'adasd', 'a.maks97@mail.ru', '87023837080'),
(14, 'ssdf', 'SDFSDf', 'sdfsdf', 'sdfsdf', 'sdfsdf'),
(15, 'Dastan', 'admin', '2222222', 'ssss', 'Ssss'),
(16, 'sadas', 'asasa', 'asasa', 'asasa', 'asas'),
(17, 'Askar', 'admin', 'aaaa', 'a.maks97@mail.ru', '87023837080'),
(18, 'Maksat', 'max_9700', '1234', '56565yhfh', '87023837080'),
(19, 'Askar', 'aaaaa', 'aaaaa', 'aaaaa', 'aaaaa');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `users2`
--
ALTER TABLE `users2`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `users2`
--
ALTER TABLE `users2`
  MODIFY `id` int(255) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
