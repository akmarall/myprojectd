
<!DOCTYPE HTML>
<html>

<head>
  <title>Akmaral_make up</title>
  <meta name="description" content="website description" />
  <meta name="keywords" content="website keywords, website keywords" />
  <meta http-equiv="content-type" content="text/html; charset=UTF-8" />
  <link rel="stylesheet" type="text/css" href="css/style.css" />
  <link rel="shortcut icom" href="C:\xampp\htdocs\akma\favicon.ico">  
     <script type="text/javascript" src="js/modernizr-1.5.min.js"></script>
        <script src="js/myJSfile.js"></script>
</head>

<body>
  <div id="main">
    <header>
      <div id="logo">
        <div id="logo_text">
          <!-- class="logo_colour", allows you to change the colour of the text -->
          <h1><a href="index.php">Akmaral_beauty</a></h1>
          <h2>“Beauty is internal.</h2>
        </div>
      </div>
      <nav>
        <div id="menu_container">
          <ul class="sf-menu" id="nav">
            <li><a href="index.php" class="active">Home</a></li>
            <li><a href="examples.php">About us</a></li>

            <li><a href="video.php">Video</a></li>
            <li><a href="#">Portfolio</a>
              <ul>
                <li><a href="price.php">Photoset</a></li>
                <li><a href="master.php">Master class</a> </li>
                <li><a href="#">Before\After</a></li>
                <li><a href="#">Weddings</a></li>
                <li><a href="#">Fashion</a></li>
              </ul>
            </li>
            <li><a href="contact.php">Contact us </a></li>
             <?php if (isset($_SESSION['login'])) {

                            echo "<li><a href=\"logout.php \">logout</a></li>";
                            
                        }
                            else{
                                echo "<li><a href=\"login.php \" >Login</a></li>";
                            }
                        

                            ?>
          </ul>
        </div>
      </nav>
    </header>